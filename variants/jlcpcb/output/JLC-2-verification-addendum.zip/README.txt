JLC-2 verification addendum. Start with docs/CONTINUED_ANALOG_REVIEW.md.
The native PCB and original JLC-2 archives are unchanged; fabrication readiness remains false.
Use tools from the complete project workspace. KiCad Flatpak supplies libngspice.
Vendor model URLs and hashes are in research/vendor-model-sources.json; obtain models into the documented .scratch paths.
ROM and manufacturer manual/model PDFs are not distributed here.
